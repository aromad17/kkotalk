import React from 'react'
import { BrowserRouter, HashRouter as Router, Route, Routes } from 'react-router-dom';
import Auth from '../routes/Auth';
import Friends from '../routes/Friends';
import Chats from '../routes/Chats';
import Find from '../routes/Find';
import More from '../routes/More';
import Profile from '../routes/Profile';
import Chatting from './Chatting';

function AppRouter({ isLoggedIn, userObj }) {

  return (

    <BrowserRouter>
      <Routes>
        {isLoggedIn ? (
          <Route path='/' element={<Friends />} />
        ) : (
          <Route path='/' element={<Auth />} />
        )}
        <Route path="/chats" element={<Chats />} />
        <Route path="/find" element={<Find />} />
        <Route path="/more" element={<More />} />
        <Route path="/profile" element={<Profile />} />
        <Route path="/chatting" element={<Chatting userObj={userObj} />} />
      </Routes>
    </BrowserRouter>
  )
}

export default AppRouter

