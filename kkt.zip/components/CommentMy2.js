import { deleteDoc, doc } from 'firebase/firestore';
import { deleteObject, ref } from 'firebase/storage';
import React from 'react'
import { IoTrashSharp } from "react-icons/io5";
import { db, storage } from '../fbase';


function CommentMy2(props) {

  const { addChat: { chat, postUrl, id } } = props;


  const onPicDelete = async (e) => {
    const deleteCofim = window.confirm("삭제하시겠습니까?");

    if (deleteCofim) {
      await deleteDoc(doc(db, "talks", `/${id}`));
      const desertRef = ref(storage, postUrl);
      await deleteObject(desertRef);
    }
  }




  return (
    <>
      {chat &&

        <span className="chat">{chat}</span>

      }

      {postUrl &&
        <div className="img_box">
          <button onClick={onPicDelete}><IoTrashSharp /></button>
          <img src={postUrl} alt='' />
        </div>
      }
    </>
  )
}

export default CommentMy2