import React, { useState } from 'react'
import '../styles/profile.scss'
import { FaTimes, FaPen } from "react-icons/fa"
import Header from '../components/Header'
import { IoCheckmarkSharp, IoCreateSharp } from "react-icons/io5";
import { db, storage } from "../fbase";
import "firebase/storage";
import { v4 as uuidv4 } from 'uuid';
import { getDownloadURL, ref, uploadString } from 'firebase/storage';
import { addDoc, collection } from 'firebase/firestore';


function MyProfile({ userObj }) {

  const [editing, setEditing] = useState(false);
  const [editBg, setEditBg] = useState(false);
  const [newBg, setNewBg] = useState('');


  const onProfileToggle = () => {
    setEditing((prev) => !prev)
  };

  const onBgToggle = () => {
    setEditBg((prev) => !prev)
  };

  const onBgChange = (e) => {

    console.log(e);
    const { target: { files } } = e;
    const theBg = files[0];

    const reader = new FileReader();

    reader.readAsDataURL(theBg);
    reader.onloadend = (finishedBg) => {
      const { currentTarget: { result } } = finishedBg;

      setNewBg(result);
    }

  };

  const onBgSubmit = async (e) => {
    e.preventDefault();

    try {
      let bgUrl = "";

      const storageRef = ref(storage, `${userObj.uid}/${uuidv4()}`);
      //내 파이어베이스 스토리지에 uuidv4를 사용하여 랜덤한 경로를 생성
      const response = await uploadString(storageRef, newBg, 'data_url');
      console.log('response->', response);

      const docRef = await addDoc(collection(db, "talks"), {
        userName: userObj.uid,
        newBg,
        createdAt: Date.now(),
      });

    } catch (error) {

      console.log("에러남");
    }

  }


  return (
    <div className='profile_wrap'>

      {/* < !--header --> */}
      <Header
        titleleft={<FaTimes />}
        titlename={" "}
        titleright={" "}
      />
      {/* <!-- //header --> */}
      < hr />
      {/* < !--main --> */}
      <main>

        {editing ? (
          <form>
            <section className="background">
              <h2 className="blind">My profile background image</h2>
              {editBg ? (
                <>
                  <div className='edit_bg'>
                    <label for="bgChanger">이미지 선택</label>
                    <input type='file' id="bgChanger" accept='image/*' onChange={onBgChange} />
                    {newBg &&
                      (
                        <>
                          <img src={newBg} alt="" />
                          <button onClick={onBgSubmit}><IoCheckmarkSharp /></button>
                        </>
                      )
                    }

                  </div>

                  <button onClick={onBgToggle}>
                    <IoCreateSharp />
                  </button>

                </>
              ) : (
                <></>
              )
              }
              <button onClick={onBgToggle}><IoCreateSharp /></button>
            </section>

            <section className="detail_profile">
              <div className="detail_profile_img empty">
                <img src={userObj.photoURL} alt=" " />
                <button onClick={onBgToggle}><IoCreateSharp /></button>
              </div>






              <div className="detail_profile_cont">
                <span className="detail_profile_name">{userObj.displayName} <button><IoCreateSharp /></button></span>
                <span className='detail_profile_email'>이메일을 설정해주세요
                  <button><IoCreateSharp /></button>
                </span>




                <ul className="detail_profile_menu">
                  <li>
                    <a href="#">
                      <button className="profile_modify" onClick={onProfileToggle}>
                        <span className="icon">
                          <FaPen />
                        </span>
                        Done
                      </button>
                    </a>
                  </li>
                  {/* <!-- //Edit Profile --> */}
                </ul>
              </div>
            </section>
          </form>
        )

































          :
          (
            <>
              <section className="background">
                <h2 className="blind">My profile background image</h2>
              </section>
              <section className="detail_profile">
                <div className="detail_profile_img empty">
                  <img src={userObj.photoURL} alt=" " />
                </div>
                <div className="detail_profile_cont">
                  <span className="detail_profile_name">{userObj.displayName}</span>
                  <input type="mail" className="profile_email" placeholder="userId@naver.com" />
                  <ul className="detail_profile_menu">
                    {/* <!-- Edit Profile --> */}
                    <li>
                      <a href="#">
                        <button onClick={onProfileToggle}>
                          <span className="icon">
                            <FaPen />
                          </span>
                          Eidt Profile
                        </button>
                      </a>
                    </li>
                    {/* <!-- //Edit Profile --> */}
                  </ul>
                </div>
              </section>
            </>
          )


        }

      </main>
      {/* <!-- //main --> */}

    </div >
  )
}

export default MyProfile