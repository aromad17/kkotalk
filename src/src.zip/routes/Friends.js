import React from 'react'
import user from '../data/user.json'
import { FaSearch } from "react-icons/fa"
import '../styles/friends.scss'
import Users from '../components/Users'

function Friends() {


  return (
    <main>
      {/* <!-- search box--> */}
      <form className="search_box" action="">
        <fieldset className="search_inner">
          <legend className="blind">검색창</legend>
          <FaSearch />
          <input type="search" name="search" id="search" placeholder="Find Friends, chats, Plus Friends, ..." />
        </fieldset>
      </form>
      {/* <!-- //search box--> */}

      {/* <!-- main_section --> */}
      <section className="main_section">
        <div className="section_header" >
          <h2>My Profile</h2>
        </div>
        <ul>
          {user.map(users => (

            <Users
              propsname={users.name}
              propsimages={users.img}
            />

          ))
          }
        </ul>
      </section>
      {/* <!--// main_section --> */}


    </main>

  )
}

export default Friends