import React from 'react'
import '../styles/more.scss'


function More() {
  return (
    <div>
      {/* <!-- header --> */}
      <header>
        {/* <!-- status_bar --> */}
        <div class="status_bar">

          <div class="left_item">
            <i class="fa-solid fa-plane"></i>
            <i class="fa-solid fa-wifi"></i>
          </div>

          <div class="center_item"><span>15</span>:<span>33</span></div>
          <div class="right_item">
            <i class="fa-regular fa-moon"></i>
            <i class="fa-brands fa-bluetooth-b"></i>
            <span><span>100</span>%</span>
            <i class="fa-solid fa-battery-three-quarters"></i>
          </div>
        </div>
        {/* <!-- //status_bar -->
        <!-- title_bar --> */}
        <div class="title_bar">
          <h1>More</h1>
          <div class="left_item"><a href="#"></a></div>
          <div class="right_item"><i class="fa-solid fa-gear"></i><a href="#"></a></div>
        </div>
        {/* <!-- //title_bar --> */}
      </header>
      {/* <!-- //header --> */}
      <hr />
      {/* <!-- main --> */}
      <main>
        {/* <!-- user_info --> */}
        <section class="user_info">
          <h2 class="blind">사용자정보</h2>
          <span class="profile_img empty"></span>
          <span class="profile_info">
            <span class="profile_name">My name</span>
            <span class="profile_email">userId@naver.com</span>
          </span>
          <span class="chat_img"><a href="#"><i class="fa-regular fa-comment"></i></a></span>
        </section>
        {/* <!-- //user_info --> */}

        {/* <!-- user_menu --> */}
        <section class="user_menu">
          <h2 class="blind">사용자 메뉴</h2>
          <ul>
            <li><a href="#"><i class="fa-regular fa-face-smile"></i>Emoticon</a></li>
            <li><a href="#"><i class="fa-solid fa-paintbrush"></i>Theme</a></li>
            <li><a href="#"><i class="fa-regular fa-hand-peace"></i>Plus Friend</a></li>
            <li><a href="#"><i class="fa-regular fa-circle-user"></i>Account</a></li>
          </ul>
        </section>
        {/* <!-- //user_menu --> */}

        {/* <!-- plus Friends --> */}
        <section class="plus_friends">
          <header>
            <h2>Plus Friends</h2>
            <span><i class="fa-solid fa-circle-info"></i>Learn More</span>
          </header>

          <ul class="plus_list">
            <li><a href="#"><i class="fa-solid fa-utensils"></i>order</a></li>
            <li><a href="#"><i class="fa-solid fa-house"></i>store</a></li>
            <li><a href="#"><i class="fa-solid fa-tv"></i>TV Channel/Radio</a></li>
            <li><a href="#"><i class="fa-solid fa-pencil"></i>Creation</a></li>
            <li><a href="#"><i class="fa-solid fa-graduation-cap"></i>Education</a></li>
            <li><a href="#"><i class="fa-solid fa-building-columns"></i>Politices/Society</a></li>
            <li><a href="#"><i class="fa-solid fa-won-sign"></i>Finance</a></li>
            <li><a href="#"><i class="fa-solid fa-video"></i>Movies/Music</a></li>
          </ul>

        </section>
        {/* <!-- //plus Friends --> */}

        {/* <!-- more app --> */}
        <section class="more_app">
          <h2 class="blind">앱 더보기</h2>
          <ul>
            <li><a href="#"><span class="app_icon"></span>Kakao Story</a></li>
            <li><a href="#"><span class="app_icon"></span></a>Path</li>
            <li><a href="#"><span class="app_icon"></span></a>Kakao friends</li>
          </ul>
        </section>
        {/* <!-- //more app --> */}
      </main>
      {/* <!-- //main --> */}
      <hr />
      {/* <!-- nav --> */}
      <nav class="tab_bar">
        <ul>
          <li><a href="index.html"><i class="fa-solid fa-user"></i>Friends</a></li>
          <li><a href="chats.html"><i class="fa-solid fa-comment"></i>Chats</a></li>
          <li><a href="find.html"><i class="fa-solid fa-magnifying-glass"></i>Find</a></li>
          <li><a href="more.html"><i class="fa-solid fa-ellipsis"></i>More</a></li>
        </ul>
      </nav>
      {/* <!-- //nav --> */}

    </div>
  )
}

export default More


