import React from 'react'
import '../styles/profile.scss'


function Profile() {
  return (
    <div>

      {/* < !--header --> */}
      <header>
        {/* <!-- status_bar --> */}
        <div class="status_bar">

          <div class="left_item">
            <i class="fa-solid fa-plane"></i>
            <i class="fa-solid fa-wifi"></i>
          </div>

          <div class="center_item"><span>15</span>:<span>33</span></div>
          <div class="right_item">
            <i class="fa-regular fa-moon"></i>
            <i class="fa-brands fa-bluetooth-b"></i>
            <span><span>100</span>%</span>
            <i class="fa-solid fa-battery-three-quarters"></i>
          </div>
        </div>
        {/* <!-- //status_bar -->
        <!-- title_bar --> */}
        <div class="title_bar">
          <div class="left_item"><a href="#"><i class="fa-solid fa-xmark"></i></a></div>
          <div class="right_item"><a href="#"><i class="fa-solid fa-user"></i></a></div>
        </div>
        {/* <!-- //title_bar --> */}
      </header>
      {/* <!-- //header --> */}
      < hr />
      {/* < !--main --> */}
      <main>
        <section class="background">
          <h2 class="blind">My profile background image</h2>
        </section>

        <section class="profile">
          <div class="profile_img empty"></div>
          <div class="profile_cont">
            <span class="profile_name">my name</span>
            <input type="mail" class="profile_email" placeholder="userId@naver.com" />
            <ul class="profile_menu">
              {/* <!-- my chatroom --> */}
              <li>
                <a href="#">
                  <span class="icon">
                    <i class="fa-solid fa-comment"></i>
                  </span>
                  My Chatroom
                </a>
              </li>
              {/* <!-- //my chatroom --> */}

              {/* <!-- Edit Profile --> */}
              <li>
                <a href="#">
                  <span class="icon">
                    <i class="fa-solid fa-pencil"></i>
                  </span>
                  Eidt Profile
                </a>
              </li>
              {/* <!-- //Edit Profile --> */}
            </ul>

          </div>
        </section>
      </main>
      {/* <!-- //main --> */}

    </div>
  )
}

export default Profile

