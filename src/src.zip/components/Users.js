import React from 'react'

function Users({ propsimg, propsname, propsmsg }) {
  return (


    <li>
      <a href="profile.html">
        <span className="profile_img empty"><img src={propsimg} /></span>
        <span className="profile_name">{propsname}</span>
        <span class="profile_messages">{propsmsg}</span>
      </a>
    </li>

    // <>
    //   <h1>No. {propsid}</h1>
    //   <h2>Name : {propsname}</h2>
    //   <img src={propsimages} alt={propsname} />
    // </>
  )
}
export default Users;