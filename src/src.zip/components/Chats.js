import React from 'Chats'
import '../styles/chats.scss'
import Header from './header'


function Chats() {
  return (
    <div>
      <Header />
      {/* < !--header --> */}

      < hr />
      {/* < !--main --> */}
      <main>
        {/* <!-- search box--> */}
        <form class="search_box" action="">
          <fieldset class="search_inner">
            <legend class="blind">검색창</legend>
            <i class="fa-solid fa-magnifying-glass"></i>
            <input type="search" name="search" id="search" placeholder="Find Friends, chats, Plus Friends, ..." />
          </fieldset>
        </form>
        {/* <!-- //search box--> */}

        {/* <!-- main_section --> */}
        <section class="main_section">
          <ul>
            <li>
              <a href="chatting.html">
                <span class="chats_img empty"></span>
                <span class="chats_cont">
                  <span class="chats_name">Friend Name</span>
                  <span class="chats_latest">Hello! This is a test MSG!</span>
                </span>
                <span class="chat_time"><span>17</span>:<span>35</span></span>
              </a>
            </li>

            <li>
              <a href="chatting.html">
                <span class="chats_img empty"></span>
                <span class="chats_cont">
                  <span class="chats_name">Friend Name</span>
                  <span class="chats_latest">Hello! This is a test MSG!</span>
                </span>
                <span class="chat_time"><span>17</span>:<span>35</span></span>
              </a>
            </li>

            <li>
              <a href="chatting.html">
                <span class="chats_img empty"></span>
                <span class="chats_cont">
                  <span class="chats_name">Friend Name</span>
                  <span class="chats_latest">Hello! This is a test MSG!</span>
                </span>
                <span class="chat_time"><span>17</span>:<span>35</span></span>
              </a>
            </li>

            <li>
              <a href="chatting.html">
                <span class="chats_img empty"></span>
                <span class="chats_cont">
                  <span class="chats_name">Friend Name</span>
                  <span class="chats_latest">Hello! This is a test MSG!</span>
                </span>
                <span class="chat_time"><span>17</span>:<span>35</span></span>
              </a>
            </li>

            <li>
              <a href="chatting.html">
                <span class="chats_img empty"></span>
                <span class="chats_cont">
                  <span class="chats_name">Friend Name</span>
                  <span class="chats_latest">Hello! This is a test MSG!</span>
                </span>
                <span class="chat_time"><span>17</span>:<span>35</span></span>
              </a>
            </li>

            <li>
              <a href="chatting.html">
                <span class="chats_img empty"></span>
                <span class="chats_cont">
                  <span class="chats_name">Friend Name</span>
                  <span class="chats_latest">Hello! This is a test MSG!</span>
                </span>
                <span class="chat_time"><span>17</span>:<span>35</span></span>
              </a>
            </li>

            <li>
              <a href="chatting.html">
                <span class="chats_img empty"></span>
                <span class="chats_cont">
                  <span class="chats_name">Friend Name</span>
                  <span class="chats_latest">Hello! This is a test MSG!</span>
                </span>
                <span class="chat_time"><span>17</span>:<span>35</span></span>
              </a>
            </li>

            <li>
              <a href="chatting.html">
                <span class="chats_img empty"></span>
                <span class="chats_cont">
                  <span class="chats_name">Friend Name</span>
                  <span class="chats_latest">Hello! This is a test MSG!</span>
                </span>
                <span class="chat_time"><span>17</span>:<span>35</span></span>
              </a>
            </li>

            <li>
              <a href="chatting.html">
                <span class="chats_img empty"></span>
                <span class="chats_cont">
                  <span class="chats_name">Friend Name</span>
                  <span class="chats_latest">Hello! This is a test MSG!</span>
                </span>
                <span class="chat_time"><span>17</span>:<span>35</span></span>
              </a>
            </li>

            <li>
              <a href="chatting.html">
                <span class="chats_img empty"></span>
                <span class="chats_cont">
                  <span class="chats_name">Friend Name</span>
                  <span class="chats_latest">Hello! This is a test MSG!</span>
                </span>
                <span class="chat_time"><span>17</span>:<span>35</span></span>
              </a>
            </li>

            <li>
              <a href="chatting.html">
                <span class="chats_img empty"></span>
                <span class="chats_cont">
                  <span class="chats_name">Friend Name</span>
                  <span class="chats_latest">Hello! This is a test MSG!</span>
                </span>
                <span class="chat_time"><span>17</span>:<span>35</span></span>
              </a>
            </li>
          </ul>
        </section>
        {/* <!--// main_section --> */}

        {/* <!-- floating btn --> */}
        <div class="chat_fa_btn">
          <a href="">
            <i class="fa-solid fa-comment"></i>
          </a>
        </div>
        {/* <!-- //floating btn --> */}
      </main>
      {/* <!-- //main --> */}
      < hr />
      {/* < !--nav --> */}
      <nav class="tab_bar">
        <ul>
          <li><a href="index.html"><i class="fa-solid fa-user"></i>Friends</a></li>
          <li><a href="chats.html"><i class="fa-solid fa-comment"></i>Chats</a></li>
          <li><a href="find.html"><i class="fa-solid fa-magnifying-glass"></i>Find</a></li>
          <li><a href="more.html"><i class="fa-solid fa-ellipsis"></i>More</a></li>
        </ul>
      </nav>
      {/* <!-- //nav --> */}
    </div>
  )
}

export default Chats













