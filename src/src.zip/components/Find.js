import React from 'react'
import '../styles/find.scss'


function Find() {
  return (
    <div>

      {/* <!-- header --> */}
      <header>
        {/* <!-- status_bar --> */}
        <div class="status_bar">

          <div class="left_item">
            <i class="fa-solid fa-plane"></i>
            <i class="fa-solid fa-wifi"></i>
          </div>

          <div class="center_item"><span>15</span>:<span>33</span></div>
          <div class="right_item">
            <i class="fa-regular fa-moon"></i>
            <i class="fa-brands fa-bluetooth-b"></i>
            <span><span>100</span>%</span>
            <i class="fa-solid fa-battery-three-quarters"></i>
          </div>
        </div>
        {/* <!-- //status_bar --> */}
        {/* <!-- title_bar --> */}
        <div class="title_bar">
          <h1>Find</h1>
          <div class="left_item"><a href="#">Edit</a></div>
          <div class="right_item"><a href="#"></a></div>
        </div>
        {/* <!-- //title_bar --> */}
      </header>
      {/* <!-- //header --> */}
      <hr />
      {/* <!-- main --> */}
      <main>
        <ul class="find_method">
          <li><a href="#"><i class="fa-solid fa-address-book"></i>Find</a></li>
          <li><a href="#"><i class="fa-solid fa-qrcode"></i>QR Code</a></li>
          <li><a href="#"><i class="fa-solid fa-mobile-screen"></i>Shake</a></li>
          <li><a href="#"><i class="fa-regular fa-envelope"></i>Invite via SMS</a></li>
        </ul>

        <section class="recommend_section">
          <header>
            <h2>Recommended Friends</h2>
          </header>
          <ul>
            <li>You Have no recommended</li>
          </ul>
        </section>
      </main>
      {/* <!-- //main --> */}
      <hr />
      {/* <!-- nav --> */}
      <nav class="tab_bar">
        <ul>
          <li><a href="index.html"><i class="fa-solid fa-user"></i>Friends</a></li>
          <li><a href="chats.html"><i class="fa-solid fa-comment"></i>Chats</a></li>
          <li><a href="find.html"><i class="fa-solid fa-magnifying-glass"></i>Find</a></li>
          <li><a href="more.html"><i class="fa-solid fa-ellipsis"></i>More</a></li>
        </ul>
      </nav>
      {/* <!-- //nav --> */}

    </div>
  )
}

export default Find


