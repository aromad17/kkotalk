import React from 'react'
import { FaPlane, FaBluetoothB, FaWifi, FaBatteryThreeQuarters, FaEllipsisH } from "react-icons/fa"
import '../styles/header.scss'

function Header({ title_name, title_left }) {
  return (
    <header>
      <div class="status_bar">
        <div class="left_item">
          <FaPlane />
          <FaWifi />
        </div>
        <div class="center_item"><span>15</span>:<span>33</span></div>
        <div class="right_item">
          <FaBluetoothB />
          <span><span>100</span>%</span>
          <FaBatteryThreeQuarters />
        </div>
      </div>
      <div class="title_bar">
        <h1>{title_name}</h1>
        <div class="left_item"><a href="#">{title_left}</a></div>
        <div class="right_item"><a href="#"><FaEllipsisH /></a></div>
      </div>
    </header >
  )
}

export default Header