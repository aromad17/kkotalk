import './App.css';
import React from 'react'
import './styles/main.scss'
import Header from './components/Header'
import Friends from './components/Friends'
import Nav from './components/Nav'


function App() {
  return (
    <div>
      <Header title_name={"Friends"} title_left={"Manage"} />
      {/* <!-- main --> */}
      <Friends />
      <Nav />
    </div>
  );
}

export default App;
